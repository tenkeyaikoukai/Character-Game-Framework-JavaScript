

function init(){
}

function routine(){
}

function keyin(keychr){
}