
var m=new Array();

var mc,sc,x,y,k,f,i,j,r,l;

function init(){

play();

}
function play(){
for(i = 0 ;i<= 19 ;i++){
for( j = 0 ; j<=19 ;j++){
m[i*20+j] = 0;
}
} 
for ( i = 0 ; i<= 19 ;i++){
r = Math.floor(Math.random() * 10) + 1;
if ( r == 1 ) { m[1*20 +i] = 1;}
else { m[i*20+ 1] = 0;}
}
draw();

}
function next(){

draw();

}
function draw(){

cls();
color(6);
for ( i =0 ; i<= 19 ;i++){
for ( j = 0 ; j<=19 ; j++){
if(m[i*20+j]==1){color(5);put(chrname("circle"),j,i);}
}
}

}

function keyin(){
}

function schroll(){
for ( i = 0 ; i<= 19 ; i++){
 r = Math.floor(Math.random() * 20 + 1);
 if ( r == 1 ){ m[1*20+i] = 1;} else {m[1*20+i] = 0;}
}

for (i=18 ; i>=0 ;i--){
 for (j = 0 ;j<=19 ;j++){
  m[(i+1)*20+j] = m[i*20+j];
 }
}  
draw(); 

}

function routine(){
schroll();
}
