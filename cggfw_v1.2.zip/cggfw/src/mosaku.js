
var chr1=new Array(
0,0,1,1,1,1,0,0,
0,1,0,0,0,0,1,0,
0,1,0,0,0,0,1,0,
0,1,0,0,0,0,1,0,
0,0,1,1,1,1,0,0
);
var chr2=new Array(
0,0,1,0,0,1,0,0,
0,1,1,1,1,1,1,0,
0,1,1,1,1,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0
);
var chr3=new Array(
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1
);
var chr4=new Array(
1,0,0,0,0,0,0,0,
1,1,1,0,0,0,0,0,
1,1,1,1,1,0,0,0,
1,1,1,1,1,1,1,0,
1,1,1,1,1,1,1,1
);
var chr5=new Array(
0,0,0,0,0,0,0,1,
0,0,0,0,0,1,1,1,
0,0,0,1,1,1,1,1,
0,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1
);
var chr6=new Array(
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,1,1,
0,0,0,0,0,0,0,0
);
var chr7=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var mosaku1=new Array(
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,1,1,1,1,1,
0,0,0,1,0,0,0,0
);
var mosaku2=new Array(
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,1,1,1,
1,0,0,1,1,0,0,1,
0,0,1,1,1,1,0,0
);
var mosaku3=new Array(
0,0,1,0,0,1,0,0,
0,0,1,0,0,1,0,0,
0,1,1,0,0,1,1,0,
0,1,0,0,0,0,1,0,
1,1,0,0,0,0,1,1
);
var mosaku4=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrs=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrc=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chro=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrr=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chre=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrnum0=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrnum1=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrnum2=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrnum3=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrnum4=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrnum5=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrnum6=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrnum7=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrnum8=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chrnum9=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);

var clck=new Audio("pingpong1.mp3");
var curx=20;
var cury=80;
var pxmtx=new Array(28,44,68,84,108,124);
var rn=0;
var py=55;
var px=pxmtx[2];
var mxmtx=new Array(44,84,124);
var chrctx=new Array(0,8,5);
var mx=1;
function init(){
draw();
}
function draw(){
cls();
var x=20;
var y=40;

puttree(x,y);
x=60;
puttree(x,y);
x=100;
puttree(x,y);
color(7);
putc(mosaku1,chrctx,mxmtx[mx],65);
putc(mosaku2,chrctx,mxmtx[mx]+8,65);
putc(mosaku3,chrctx,mxmtx[mx]+8,70);
}
function keyin(keychr){
if ( keychr=="left" & mx > 0 ) { mx = mx - 1 ;}
if ( keychr=="right" & mx < 2 ){ mx = mx + 1 ;}
 draw();  

}

function puttree(x,y){
color(4);
putc(chr5,chrctx,x+8,y);
putc(chr3,chrctx,x+16,y);
putc(chr4,chrctx,x+24,y);
putc(chr5,chrctx,x+8,y+5);
putc(chr3,chrctx,x+16,y+5);
putc(chr4,chrctx,x+24,y+5);
putc(chr5,chrctx,x,y+10);
putc(chr3,chrctx,x+8,y+10);
putc(chr3,chrctx,x+16,y+10);
putc(chr3,chrctx,x+24,y+10);
putc(chr4,chrctx,x+32,y+10);
color(2);
putc(chr3,chrctx,x+16,y+15);
putc(chr3,chrctx,x+16,y+20);
putc(chr3,chrctx,x+16,y+25);
putc(chr3,chrctx,x+16,y+30);
}
function routine(){
/*
ctx.fillStyle="rgb(0,0,0)";
put(chr3,chrctx,px,py);
ctx.fillStyle="rgb(255,0,255)";
clck.play();
py+=8;
if(py>=75){px=pxmtx[Math.floor(Math.random()*6)];py=55;} 
put(chr2,chrctx,px,py);
*/
}
function inomove(){
}
function jump(){
}
function thrashtree(){
}

