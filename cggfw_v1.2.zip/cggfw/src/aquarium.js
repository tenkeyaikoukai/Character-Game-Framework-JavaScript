
var fishx=new Array(0,2,4,2,7,15,10,12);
var fishy=new Array(0,5,6,9,12,15,10,8)
var fishd=new Array(0,1,3,1,3,3,1,1);
var kombud=new Array(0,1,2);

function init(){

settimer(500);
drawwave();
drawchr();

}

function keyin(){
} 
 
function routine(){
var i,r;
for(i=1;i<=7;i++){
r=Math.floor(Math.random()*3);
if(r==1 && fishy[i]>3){fishy[i]--;}
if(r==2 && fishy[i]<18){fishy[i]++;}
fishx[i]=fishx[i]+fishd[i]-2;
if(fishd[i]==1 && fishx[i]<3){fishd[i]=3;}
if(fishd[i]==3 && fishx[i]>16){fishd[i]=1;}
}
cls();
drawchr();
drawwave();
if(kombud[1]==1){kombud[1]=2;}else{kombud[1]=1;}
if(kombud[2]==1){kombud[2]=2;}else{kombud[2]=1;}
}
function drawchr(){

// draw fish

var i;

for(i=1;i<=7;i++){
color(i);
if(fishd[i]==1){
put(chrname("se"),fishx[i],fishy[i]);
put(chrname("sw"),fishx[i]+1,fishy[i]);
put(chrname("se"),fishx[i]+2,fishy[i]);

}else{

put(chrname("sw"),fishx[i],fishy[i]);
put(chrname("se"),fishx[i]-1,fishy[i]);
put(chrname("sw"),fishx[i]-2,fishy[i]);

}
}

//draw kombu

color(4);
if(kombud[1]==1){
put(chrname("se"),5,14);
put(chrname("ne"),5,15);
put(chrname("sw"),6,16);
put(chrname("nw"),6,17);
put(chrname("se"),5,18);
put(chrname("ne"),5,19);
}
if(kombud[1]==2){
put(chrname("sw"),6,14);
put(chrname("nw"),6,15);
put(chrname("se"),5,16);
put(chrname("ne"),5,17);
put(chrname("sw"),6,18);
put(chrname("nw"),6,19);
}
if(kombud[2]==1){
put(chrname("se"),15,14);
put(chrname("ne"),15,15);
put(chrname("sw"),16,16);
put(chrname("nw"),16,17);
put(chrname("se"),15,18);
put(chrname("ne"),15,19);
}
if(kombud[2]==2){
put(chrname("sw"),16,14);
put(chrname("nw"),16,15);
put(chrname("se"),15,16);
put(chrname("ne"),15,17);
put(chrname("sw"),16,18);
put(chrname("nw"),16,19);
}

}

function drawwave(){
var i,r;
for ( i =0 ; i<= 19 ;i++){
if(i<=10 || i>=14){r=Math.floor(Math.random()*2);}
color(5);put(chrname("wave"),i,r);
}

}