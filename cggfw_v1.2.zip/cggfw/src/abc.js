


function init(){
cls();
color(5);
put(chra,1,5);
put(chrb,2,5);
put(chrc,3,5);
put(chrd,4,5);
put(chre,5,5);
put(chrf,6,5);
put(chrg,7,5);
color(4);
put(chrh,1,7);
put(chri,2,7);
put(chrj,3,7);
put(chrk,4,7);
put(chrl,5,7);
put(chrm,6,7);
put(chrn,7,7);
color(3);
put(chro,1,9);
put(chrp,2,9);
put(chrq,3,9);
put(chrr,4,9);
put(chrs,5,9);
put(chrt,6,9);
put(chru,7,9);
color(1);
put(chrv,1,11);
put(chrw,2,11);
put(chrx,3,11);
put(chry,4,11);
put(chrz,5,11);

}

function routine(){

}
