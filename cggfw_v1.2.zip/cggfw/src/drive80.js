
var m=new Array();
var m2=new Array();
var curx=20;
var cury=80;

var num=50;//�G�o���p�x�F�������ق��������Bdefault=30
var mc,sc,x,y,df,ti,tin,k,f,i,j,r,l,rx,counter,wait,waitcounter;

function init(){

f=0;
counter=25;
rx=5;
settimer(10);
play();
wait=10;
waitcounter=wait;
}
function play(){
if (f==0 ) {
f=1;
for(i = 0 ;i<= 19 ;i++){
for( j = 0 ; j<=19 ;j++){
m[i*20+j] = 0;
}
} 
for ( i = 0 ; i<= 19 ;i++){
 m[i*20+ 1] = 0;
}
r = Math.floor(Math.random() * 3) + 1;
if ( r == 1 & rx>=1) {rx=rx-1;}
if ( r == 2 & rx<=8) {rx=rx+1;}

 m[1*20 +rx] = 1;
m[1*20 +rx+10] = 1;
sc = 0 ;
x = 10;
y = 18;
df = 0;
k=1;
m[y*20+x] = 3;
draw();
sc = sc + 1;

}


draw();


}
function next(){

draw();

}
function draw(){

cls();
for ( i =0 ; i<= 19 ;i++){
for ( j = 0 ; j<=19 ; j++){
if(m[i*20+j]==1){color(7);put(chr3,j,i);}
if(m[i*20+j]==2){color(4);put(chr1,j,i);}
if(m[i*20+j]==3){color(6);put(chr1,j,i);}
if(m[i*20+j]==4){color(7);put(chr8,j,i);}
}
}

}
function keyin(keychr){
if ( keychr=="left" & x >= 1 ) { x = x - 1 ;}
if ( keychr=="right" & x < 19 ){ x = x + 1 ;}
if (keychr=="z" && wait>2){wait--;}else{if(wait<=10){wait++;}}
}
function routine(){
if(waitcounter==0){
waitcounter=wait;
schroll();
}
waitcounter--;
}
function schroll(){
beep(0);
r = Math.floor(Math.random() * 8)+rx+2;
m[1*20+r] = 2;
r = Math.floor(Math.random() * 3) + 1;
if ( r == 1 & rx>=2) {rx=rx-1;}
if ( r == 2 & rx<=7) {rx=rx+1;}

 m[1*20 +rx] = 1;
m[1*20 +rx+10] = 1;
 m[1*20 +rx-1] = 4;
m[1*20 +rx+11] = 4;
for (i=18 ; i>=0 ;i--){
for (j = 0 ;j<=19 ;j++){
m[(i+1)*20+j] = m[i*20+j];
}
}  
if (m[y*20+x] == 1�@| m[y*20+x] == 2){
f=0;cleartimer();disp.innerHTML="SCORE" + sc;
}else{
m[y*20+x] = 3;
draw(); 
sc=sc+1;
counter=counter-1;
if(counter==0){counter=Math.floor(Math.random()*5)+1;}
}

}


