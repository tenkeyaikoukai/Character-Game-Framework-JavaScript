
var pcg1=new Array(
0,0,0,0,0,0,0,0,
0,0,1,0,0,1,0,0,
1,1,1,0,0,1,1,1,
1,1,1,1,1,1,1,1,
0,0,1,0,0,1,0,0,
0,0,1,0,0,1,0,0,
0,0,1,1,1,1,0,0,
1,1,1,0,0,1,1,1,
1,1,1,1,1,1,1,1,
0,0,1,0,0,1,0,0
);
var pcg2=new Array(
0,0,1,1,1,1,0,0,
0,1,0,0,0,0,1,0,
1,0,0,1,1,0,0,1,
1,0,1,0,0,1,0,1,
1,0,1,0,0,0,0,1,
1,0,1,0,1,1,0,1,
1,0,1,0,0,1,0,1,
1,0,0,1,1,0,0,1,
0,1,0,0,0,0,1,0,
0,0,1,1,1,1,0,0
);
var m=new Array();
var m2=new Array();
var curx=20;
var cury=80;
var mc,sc,x,y,k,f,i,j,r,l,counter,getcounter,chaincounter,chainflag;
var clck=new Audio("pingpong1.mp3")
var beep=new Audio("beep.mp3");
var num=50;//�G�o���p�x�F�������ق��������Bdefault=30

var chrctx=new Array(0,8,10);
function init(){
play();

}
function play(){

sc = 0 ;
x = 10;
y = 8;
counter=0;
chaincounter=0;
chainflag=0;
k=1;
m[y*20+x] = 3;
draw();
sc = sc + 1;


draw();


}
function next(){

draw();

}
function draw(){

ctx.fillStyle="rgb(0,0,0)";
ctx.fillRect(0,0,640,400);
ctx.fillStyle="rgb(255,255,0)";

ctx.fillStyle="rgb(0,0,255)";put(pcg1,chrctx,5*8,5*10);
ctx.fillStyle="rgb(255,255,0)";put(pcg2,chrctx,6*8,6*10);



}
function keyin(){
if ( event.keyCode == 37 & x >= 1 ) { x = x - 1 ;}
if ( event.keyCode == 39 & x < 19 ){ x = x + 1 ;}
}
function schroll(){
clck.play();
  
if (m[y*20+x] == 1){clearInterval(ti);disp.innerHTML="GAME OVER";mssg.innerHTML="";
}

if(m[y*20+x]!=1 & m[y*20+x]!=2){m[y*20+x] = 3;
draw(); 
sc=sc+1;
counter=counter+1;
disp.innerHTML="SCORE "+sc;
if(counter==25 & chainflag==0){chaincounter=0;counter=0;}
if(counter==25 & chainflag==1){chainflag=0;counter=0;}
}




}
function routine(){

}
