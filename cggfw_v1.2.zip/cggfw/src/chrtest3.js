
var ct=0;
function init(){

var x=3;
var y=8;
puthouse(x,y);
settimer(500);
}
function puthouse(x,y){
cls();
color(2);
put(chr5,x+2,y);
put(chr4,x+3,y);
put(chr3,x+4,y);
put(chr5,x+1,y+1);
put(chr3,x+2,y+1);
put(chr3,x+3,y+1);
put(chr3,x+4,y+1);
put(chr5,x,y+2);
put(chr3,x+1,y+2);
put(chr3,x+2,y+2);
put(chr3,x+3,y+2);
put(chr3,x+4,y+2);
put(chr4,x+5,y+2);
color(7);
put(chr3,x+1,y+3);
put(chr3,x+2,y+3);
put(chr3,x+3,y+3);
put(chr3,x+4,y+3);
put(chr3,x+1,y+4);
put(chr3,x+4,y+4);
put(chr3,x+1,y+5);
put(chr3,x+4,y+5);
put(chr3,x+1,y+6);
put(chr3,x+2,y+6);
put(chr3,x+3,y+6);
put(chr3,x+4,y+6);
color(4);
put(chr8,x+5,y+6);
put(chr8,x+6,y+6);
color(5);
put(chr15,x+2,y+4);
put(chr15,x+3,y+4);
put(chr15,x+2,y+5);
put(chr15,x+3,y+5);
}
function routine(){
color(0);
put(chr3,7,7);
put(chr3,7,6);
put(chr3,7,5);
put(chr3,7,4);
color(7);
put(chr1,7,7-ct);
if(ct<=2){ct++;}else{ct=0;}
//clck.play();
}