
var m=new Array(
0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,
0,0,2,0,0,0,0,0,1,1,1,0,0,0,5,5,5,5,5,0,
0,2,2,4,0,0,0,1,1,1,0,0,0,0,5,0,0,0,5,0,
0,0,2,2,0,0,0,1,1,1,0,0,0,0,5,5,6,5,5,0,
0,0,2,2,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
0,0,2,0,0,0,1,1,1,0,0,0,0,0,2,2,2,0,0,0,
0,0,0,0,0,0,1,1,1,0,0,0,0,0,2,2,2,4,0,0,
0,0,0,0,0,3,3,3,0,0,0,0,0,2,2,2,0,0,0,0,
0,0,0,0,1,1,1,0,0,0,0,0,0,0,2,2,0,0,0,0,
0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,2,0,0,0,0,
0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0,0,0,
1,0,0,0,0,0,0,0,0,2,2,2,2,0,0,0,0,0,0,0,
0,0,6,6,6,6,6,0,2,2,2,2,0,0,0,0,4,0,0,0,
0,0,6,0,0,0,6,0,0,2,2,2,0,0,0,0,0,0,0,0,
0,0,6,0,0,0,6,0,0,0,2,2,0,0,0,0,0,0,0,0,
0,0,6,6,6,6,6,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
);
var x=20;
var y=20;
var bx=10;
var by=10;
var hp=100;
var dex=3;
var agl=3;
var ehp,edx,eag;

//1:boots 2:bat 3:pachinko

var item=new Array(0,0,0,0,0);
// inputmodename=("","field","fight");
var inputmode="field";
function init(){
play();
}
function play(){

draw();

}

function draw(){

cls();
for ( i =0 ; i<= y-1 ;i++){
for ( j = 0 ; j<=x-1 ; j++){
if(m[i*x+j]==1){color(5);put(chrname("fill"),j,i);}
if(m[i*x+j]==2){color(4);put(chrname("spade"),j,i);}
if(m[i*x+j]==3){color(7);put(chrname("equal"),j,i);}
if(m[i*x+j]==4){color(7);put(chrname("flag"),j,i);}
if(m[i*x+j]==5){color(2);put(chrname("brick"),j,i);}
if(m[i*x+j]==6){color(4);put(chrname("sharp"),j,i);}
}
}
   color(7);
   put(chrname("circle"),bx,by);

}

// input mode field,fight,

function keyin(keychr){

 switch(inputmode){
  case "field":
   if(keychr=="right" & bx<19){bx++;}
   if(keychr=="left" & bx>0){bx--;}
   if(keychr=="down" & by<19){by++;}
   if(keychr=="up" & by>0){by--;}
movecheck();
  break;

  case 2:
  break;
  default:
  break;
  } 
draw();
}

function routine(){

}
function next(){
draw();
}

function movecheck(){

}
