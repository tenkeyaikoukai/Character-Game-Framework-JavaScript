
var x=1;
var y=1;

function init(){
var i,j;
color(7);
for(i=1;i<=9;i++){
for(j=1;j<=10-i;j++){
put(chrname("circle"),i,j);
}
}
color(6);
put(chrname("circle"),1,1);

}

function routine(){
var r=Math.floor(Math.random()*2);
if(r==1){x++;}else{y++;}
var sum=x+y;
if(sum>10){x=1;y=1;init();}
color(6);
put(chrname("circle"),x,y);
}
