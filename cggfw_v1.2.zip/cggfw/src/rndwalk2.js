

var x=10;
var y=1;
var dx;
function init(){
ctx.strokeStyle="rgb(255,255,255)";
dx=Math.floor(Math.random()*2)+1;
if(dx==2){dx=-1;}

var i,j;
/*
color(7);
for(i=1;i<=9;i++){
for(j=1;j<=10-i;j++){
put(chrname("circle"),i,j);
}
}
*/
}

function routine(){
cls();
drawframe();
var i,j;

y++;
x+=dx;
var r=Math.floor(Math.random()*2);
if(r==1 && y%3==0){dx=-dx;}

if(y>10){dx=0;}
if(y>18){
dx=Math.floor(Math.random()*2)+1;
if(dx==2){dx=-1;}
x=10;y=0;
}
color(6);
put(chrname("circle"),x,y);
}

function drawframe(){
var x1=320;
var y1=20;
var x2=16;
var y2=220;
var i;
for(i=0;i<=11;i+=3){
ctx.moveTo(x1,y1);
ctx.lineTo(x2,y2);
ctx.lineTo(x2,400);
ctx.stroke();
x1+=3*32;
y1+=3*20;
x2+=5*32;
}
var x1=320;
var y1=20;
var x2=624;
var y2=220;
for(i=0;i<=11;i+=3){
ctx.moveTo(x1,y1);
ctx.lineTo(x2,y2);
ctx.lineTo(x2,400);
ctx.stroke();
x1-=3*32;
y1+=3*20;
x2-=5*32;
}
}
