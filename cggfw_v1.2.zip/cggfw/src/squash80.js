
var bx=6;
var by=16;
var dx=-1;
var dy=-1;
var mx=4;

function init(){

draw();
settimer(100);

}

function routine(){
cls();

if(dx==-1 && bx<=1){dx=1;}
if(dx==1 && bx>=10){dx=-1;}
if(dy==-1 && by<=1){dy=1;}
//if(dy==1 && by>=16){dy=-1;}
bx+=dx;
by+=dy;
if(by==16 && dy==1){
if((mx-bx)>=-2 &&(mx-bx)<=2){dy=-1;}
}
if(by>=18){cleartimer();}
draw();

}
function draw(){

color(7);
put(chrname("circle"),bx,by);
for(i=0;i<=2;i++){
put(chrname("equal"),mx+i,17);
}
for(i=0;i<=19;i++){
put(chrname("fill"),0,i);
put(chrname("fill"),11,i);
}
for(i=0;i<=11;i++){
put(chrname("fill"),i,0);
put(chrname("fill"),i,19);
}
}
function keyin(keycode){
if(keycode=="left" && mx>=2){mx--;}
if(keycode=="right" && mx<=7){mx++;}
}


