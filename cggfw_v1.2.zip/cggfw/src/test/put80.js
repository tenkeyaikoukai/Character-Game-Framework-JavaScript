window.onload=(function(){
ctx=document.getElementById("cvs").getContext("2d");
init();
});
function put(chr,chrctx,x,y){
var i,j;
//ctx.fillStyle="rgb(255,255,255)";
for(i=0;i<=chrctx[2]-1;i++){
for(j=0;j<=chrctx[1]-1;j++){
if(chr[i*chrctx[1]+j]==1){
ctx.fillRect((x+j)*4,(y+i)*4,4,4);
}
}
}
}

function vramclr(){
}
function vscroll(){
}
function setcolor(cc){
ctx.fillStyle="rgb(0,0,0)";
}
