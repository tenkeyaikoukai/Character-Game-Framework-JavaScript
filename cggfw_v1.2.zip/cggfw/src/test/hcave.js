
var chr1=new Array(
0,0,1,1,1,1,0,0,
0,1,0,0,0,0,1,0,
0,1,0,0,0,0,1,0,
0,1,0,0,0,0,1,0,
0,0,1,1,1,1,0,0
);
var chr2=new Array(
0,0,1,0,0,1,0,0,
0,1,1,1,1,1,1,0,
0,1,1,1,1,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0
);
var chr3=new Array(
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1
);
var chr4=new Array(
1,0,0,0,0,0,0,0,
1,1,1,0,0,0,0,0,
1,1,1,1,1,0,0,0,
1,1,1,1,1,1,1,0,
1,1,1,1,1,1,1,1
);

var chr5=new Array(
0,0,0,0,0,0,0,1,
0,0,0,0,0,1,1,1,
0,0,0,1,1,1,1,1,
0,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1
);
var chr6=new Array(
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,1,1,
0,0,0,0,0,0,0,0
);
var chr7=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var m=new Array();
var curx=20;
var cury=80;
var x=20;
var y=20;
var num,r;
var chrctx=new Array(0,8,5);
var height=5;
var grad=1;
function init(){
play();

}
function play(){

ctx.fillStyle="rgb(255,255,0)";
put(chr1,chrctx,50,50);
}
function next(){

scroll();
gen1line();
draw();

}
function draw(){

ctx.fillStyle="rgb(0,0,0)";
ctx.fillRect(0,0,640,400);
ctx.fillStyle="rgb(255,255,0)";
for ( i =0 ; i<= y-1 ;i++){
for ( j = 0 ; j<=x-1 ; j++){
if(m[i*x+j]==1){put(chr1,chrctx,j*8,i*5);}
}
}

}

function puttree(x,y){
ctx.fillStyle="rgb(0,255,0)";

put(chr5,chrctx,x+8,y);
put(chr3,chrctx,x+16,y);
put(chr4,chrctx,x+24,y);
put(chr5,chrctx,x+8,y+5);
put(chr3,chrctx,x+16,y+5);
put(chr4,chrctx,x+24,y+5);
put(chr5,chrctx,x,y+10);
put(chr3,chrctx,x+8,y+10);
put(chr3,chrctx,x+16,y+10);
put(chr3,chrctx,x+24,y+10);
put(chr4,chrctx,x+32,y+10);
ctx.fillStyle="rgb(255,0,0)";
put(chr3,chrctx,x+16,y+15);
put(chr3,chrctx,x+16,y+20);
put(chr3,chrctx,x+16,y+25);
put(chr3,chrctx,x+16,y+30);
}
function routine(){
next();
}
